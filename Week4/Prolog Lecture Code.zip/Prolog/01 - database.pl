likes(wallace, cheese).
likes(grommit, cheese).
likes(wendolene, sheep).

dog(grommit).
man(wallace).

likes_cheese(Person) :-
    likes(Person, cheese).

friend(X, Y) :-
    likes(X,Z),
    likes(Y,Z),
    X \= Y.


greet(hamish):- 
    write('How are you doin, pal?').
greet(amelia):- 
    write('Nice to see you!').
greet(Anyone) :-
    format('Hello generically, ~w', Anyone).
