tie(cupids).
tie(happy_faces).
tie(leprechauns).
tie(reindeer).

rel(daughter).
rel(father_in_law).
rel(sister).
rel(uncle).

mr(crow).
mr(evans).
mr(hurley).
mr(speigler).

solve :-
    tie(CrowTie), tie(EvansTie), 
    tie(HurleyTie), tie(SpeiglerTie),
    all_different([CrowTie, EvansTie, HurleyTie, SpeiglerTie]),

    rel(CrowRel), rel(EvansRel), 
    rel(HurleyRel), rel(SpeiglerRel),
    all_different([CrowRel, EvansRel, HurleyRel, SpeiglerRel]),

    Answer = [  [crow, CrowTie, CrowRel],
                [evans, EvansTie, EvansRel],
                [hurley, HurleyTie, HurleyRel],
                [speigler, SpeiglerTie, SpeiglerRel] ],

    %Rule 1
    \+member([_, leprechauns, daughter], Answer),

    %Rule 2
    \+member([crow, reindeer, _], Answer),
    \+member([crow, happy_faces, _], Answer),

    %Rule 3
    \+member([speigler, _, uncle], Answer),

    %Rule 4
    \+member([_, happy_faces, sister], Answer),

    %Rule 5
    ( (member([evans, leprechauns, _], Answer),
    member([speigler, _, father_in_law], Answer));

    (member([evans, _, father_in_law], Answer),
    member([speigler, leprechauns, _], Answer)) ),

    %Rule 6
    member([hurley, _, sister], Answer),

    print_ans(crow, CrowTie, CrowRel),
    print_ans(evans, EvansTie, EvansRel),
    print_ans(hurley, HurleyTie, HurleyRel),
    print_ans(speigler, SpeiglerTie, SpeiglerRel).

print_ans(Mr, Tie, Rel) :-
    format('Mr. ~w got the ~w from ~w~n', [Mr, Tie, Rel]).
    
all_different([H|T]) :-
    \+member(H, T).
% all_different([H|T]) :- member(H, T), !, fail.

all_different([_ | T]) :-
    all_different(T).
all_different([]).
