male(james1).
male(charles1).
male(charles2).
male(james2).
male(george1).

female(catherine).
female(elizabeth).
female(sophia).

parent(charles1, james1).
parent(elizabeth, james1).
parent(charles2, charles1).
parent(catherine, charles1).
parent(james2, charles1).
parent(sophia, elizabeth).
parent(george1, sophia).

grandparent(Child, Grandparent) :-
    parent(Child, Parent),
    parent(Parent, Grandparent).

sibling(X,Y) :-
    parent(X, Parent),
    parent(Y, Parent),
    X \= Y.

brother(X, Y) :-
    sibling(X,Y),
    male(Y).

sister(X, Y) :-
    sibling(X,Y),
    female(Y).

ancestor(X,Y) :-
    parent(X, Y).
ancestor(X,Y) :-
    parent(X, Z),
    ancestor(Z, Y).