hello :-
    print('Hello World!'),
    nl,
    format('~w ~w whatever ~t~n', ['hello', 'goodbye']).